#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N 5

int main( int argc , char * argv[] )
{
  int i ; 
  srandom(getpid()) ;
  int Nb = random()%N ; 

  printf(" Debut du programme %s\n" , argv[0] ) ;
  for(i=0 ; i<Nb ; i++) 
    {
      printf("\t - [%s] : etape %d/%d\n" , 
	     argv[0] , i+1 , Nb ) ;
      sleep(1) ;
    }
  printf(" Fin du programme %s\n" , argv[0] ) ;

  int cr = random()%N ;
  printf(" --> retour %s : %d\n" , argv[0] , cr ) ;  

  exit(cr);
}
