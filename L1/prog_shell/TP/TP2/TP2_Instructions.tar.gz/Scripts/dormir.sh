#!/bin/bash

sommeil=$1
echo "dormir.sh : je m'endors jusqu'a ce que que vous tapiez une touche"
read V
echo "dormir.sh : je me reveille"