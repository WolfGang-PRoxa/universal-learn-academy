#!/bin/bash
nom=`basename $0`
echo  "Debut $nom" 
sleep 3 &
ps | wc -l
echo  "Fin $nom "  
