#!/bin/bash

sommeil=$1
nom=`basename $0`
echo "je suis $nom et je vais m'endormir pour $sommeil secondes, vais je me reveiller ?"
./dormir.sh $sommeil # Appel d'un shell-fils qui va ex�cuter "./dormir.sh"
echo "je suis $nom, j'ai de la chance, je me suis reveillee !!!"
echo "je suis $nom, et je  m'endors a nouveau pour $sommeil secondes, aurais je encore de la chance de me reveiller ?"
exec ./dormir.sh $sommeil # Remplacement du shell courant par "./dormir.sh"
echo "Suis-je narcolepsique ?"

exit 0

